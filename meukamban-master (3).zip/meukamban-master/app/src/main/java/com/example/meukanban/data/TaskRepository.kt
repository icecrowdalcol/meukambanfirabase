package com.example.meukanban.data

import com.example.meukanban.data.model.Status
import com.example.meukanban.data.model.Task
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.firestore

/**
 * Repositório das tarefas, ligado à coleção "tarefas" do Cloud Firestore
 * (projeto dashboard-51703), no mesmo padrão de campos de "solicitacoes_portal".
 *
 * Mantém um listener em tempo real com as tarefas do usuário logado; toda vez
 * que algo muda no Firestore (inclusive gravações feitas pelo próprio app),
 * a lista local é atualizada e as abas registradas em [addObserver] são avisadas.
 */
object TaskRepository {

    private const val COLLECTION_TASKS = "tarefas"

    private val tasks = mutableListOf<Task>()
    private val observers = mutableSetOf<(Exception?) -> Unit>()

    private var registration: ListenerRegistration? = null
    private var listeningUid: String? = null

    private val collection get() = Firebase.firestore.collection(COLLECTION_TASKS)

    fun getByStatus(status: Status): List<Task> = tasks.filter { it.status == status }

    /**
     * Registra uma aba para ser avisada quando a lista mudar.
     * O observer recebe null em caso de sucesso, ou a exceção se a leitura falhar.
     */
    fun addObserver(observer: (Exception?) -> Unit) {
        observers.add(observer)
        startListening()
    }

    fun removeObserver(observer: (Exception?) -> Unit) {
        observers.remove(observer)
    }

    /**
     * Garante que o listener em tempo real está ativo para o usuário logado.
     * Pode ser chamado várias vezes (ex.: no onResume das abas); se já estiver
     * escutando o mesmo usuário, não faz nada.
     */
    fun startListening() {
        val uid = Firebase.auth.currentUser?.uid
        if (uid == null) {
            stopListening()
            notifyObservers(IllegalStateException("Usuário não está logado."))
            return
        }
        if (registration != null && listeningUid == uid) return

        stopListening()
        listeningUid = uid
        registration = collection
            .whereEqualTo("criadoPorUid", uid)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    // O Firestore encerra o listener após um erro (ex.: PERMISSION_DENIED).
                    // Limpa o registro para que a próxima chamada a startListening() tente de novo.
                    registration?.remove()
                    registration = null
                    listeningUid = null
                    notifyObservers(error)
                    return@addSnapshotListener
                }
                val docs = snapshot?.documents.orEmpty().sortedBy { doc ->
                    doc.getTimestamp("criadoEm", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                tasks.clear()
                tasks.addAll(docs.map { it.toTask() })
                notifyObservers(null)
            }
    }

    /** Para de escutar o Firestore e limpa a lista (usar no logout). */
    fun stopListening() {
        registration?.remove()
        registration = null
        listeningUid = null
        tasks.clear()
    }

    private fun notifyObservers(error: Exception?) {
        observers.toList().forEach { it(error) }
    }

    private fun DocumentSnapshot.toTask(): Task = Task(
        id = id,
        description = getString("descricao") ?: getString("titulo") ?: "",
        status = statusFromLabel(getString("status"))
    )

    /**
     * Insere uma nova tarefa na coleção "tarefas". Exige usuário logado.
     * A lista local é atualizada pelo listener em tempo real.
     */
    fun insert(
        description: String,
        status: Status,
        onSuccess: (Task) -> Unit,
        onFailure: (Exception) -> Unit
    ) {
        val user = Firebase.auth.currentUser
        if (user == null) {
            onFailure(IllegalStateException("Usuário não está logado."))
            return
        }

        val document = collection.document()
        val task = Task(id = document.id, description = description, status = status)

        val data = hashMapOf(
            "titulo" to task.description,
            "descricao" to task.description,
            "status" to statusLabel(task.status),
            "criadoEm" to FieldValue.serverTimestamp(),
            "criadoPor" to (user.email ?: ""),
            "criadoPorUid" to user.uid
        )

        document.set(data)
            .addOnSuccessListener { onSuccess(task) }
            .addOnFailureListener { exception -> onFailure(exception) }
    }

    /** Atualiza descrição e status da tarefa no Firestore. */
    fun update(task: Task, onComplete: (Exception?) -> Unit = {}) {
        val data = mapOf(
            "titulo" to task.description,
            "descricao" to task.description,
            "status" to statusLabel(task.status),
            "atualizadoEm" to FieldValue.serverTimestamp()
        )
        collection.document(task.id).update(data)
            .addOnSuccessListener { onComplete(null) }
            .addOnFailureListener { onComplete(it) }
    }

    /** Exclui a tarefa do Firestore. */
    fun remove(task: Task, onComplete: (Exception?) -> Unit = {}) {
        collection.document(task.id).delete()
            .addOnSuccessListener { onComplete(null) }
            .addOnFailureListener { onComplete(it) }
    }

    fun move(task: Task, newStatus: Status, onComplete: (Exception?) -> Unit = {}) {
        if (newStatus == task.status) {
            onComplete(null)
            return
        }
        update(task.copy(status = newStatus), onComplete)
    }

    fun moveForward(task: Task, onComplete: (Exception?) -> Unit = {}) {
        val next = when (task.status) {
            Status.TODO -> Status.DOING
            Status.DOING -> Status.DONE
            Status.DONE -> Status.DONE
        }
        move(task, next, onComplete)
    }

    fun moveBack(task: Task, onComplete: (Exception?) -> Unit = {}) {
        val previous = when (task.status) {
            Status.TODO -> Status.TODO
            Status.DOING -> Status.TODO
            Status.DONE -> Status.DOING
        }
        move(task, previous, onComplete)
    }

    private fun statusLabel(status: Status): String = when (status) {
        Status.TODO -> "A Fazer"
        Status.DOING -> "Fazendo"
        Status.DONE -> "Feita"
    }

    private fun statusFromLabel(label: String?): Status = when (label) {
        "Fazendo" -> Status.DOING
        "Feita" -> Status.DONE
        else -> Status.TODO
    }
}
