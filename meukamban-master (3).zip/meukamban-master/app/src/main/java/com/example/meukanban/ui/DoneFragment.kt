package com.example.meukanban.ui

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.meukanban.R
import com.example.meukanban.data.TaskRepository
import com.example.meukanban.data.model.Status
import com.example.meukanban.data.model.Task
import com.example.meukanban.databinding.FragmentDoneBinding
import com.example.meukanban.ui.adapter.TaskAdapter
import com.example.meukanban.util.showBottomSheet

class DoneFragment : Fragment() {

    private lateinit var taskAdapter: TaskAdapter

    private var _binding: FragmentDoneBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDoneBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initRecyclerViewTask()
        refreshTasks()
        TaskRepository.addObserver(tasksObserver)
    }

    override fun onResume() {
        super.onResume()
        refreshTasks()
        TaskRepository.startListening()
    }

    // Erros de leitura são exibidos só pela aba "A Fazer", para não repetir a mensagem.
    private val tasksObserver: (Exception?) -> Unit = {
        if (_binding != null) refreshTasks()
    }

    private fun showError(messageRes: Int, error: Exception?) {
        if (error == null || _binding == null) return
        showBottomSheet(message = getString(messageRes, error.localizedMessage ?: ""))
    }

    private fun initRecyclerViewTask() {
        taskAdapter = TaskAdapter(requireContext()) { task, option -> optionSelected(task, option) }

        with(binding.recyclerViewTask) {
            layoutManager = LinearLayoutManager(requireContext())
            setHasFixedSize(true)
            adapter = taskAdapter
        }
    }

    private fun optionSelected(task: Task, option: Int) {
        when (option) {
            TaskAdapter.SELECT_REMOVER -> confirmRemove(task)
            TaskAdapter.SELECT_EDIT -> editTask(task)
            TaskAdapter.SELECT_DETAILS -> showDetails(task)
            TaskAdapter.SELECT_BACK -> {
                TaskRepository.moveBack(task) { showError(R.string.error_update_task_firebase, it) }
            }
        }
    }

    private fun confirmRemove(task: Task) {
        showBottomSheet(
            titleDialog = R.string.confirm_delete_title,
            titleButton = R.string.confirm_delete_button,
            message = getString(R.string.confirm_delete_message, task.description)
        ) {
            TaskRepository.remove(task) { showError(R.string.error_delete_task_firebase, it) }
        }
    }

    private fun editTask(task: Task) {
        findNavController().navigate(
            R.id.action_homeFragment_to_formTaskFragment,
            FormTaskFragment.newBundle(task)
        )
    }

    private fun showDetails(task: Task) {
        showBottomSheet(
            titleDialog = R.string.task_details_title,
            message = task.description
        )
    }

    private fun refreshTasks() {
        taskAdapter.submitList(TaskRepository.getByStatus(Status.DONE))
    }

    override fun onDestroyView() {
        TaskRepository.removeObserver(tasksObserver)
        super.onDestroyView()
        _binding = null
    }
}
